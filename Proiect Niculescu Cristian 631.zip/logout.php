<?php
session_start(); 


session_unset();  // Unset toate variabilele
session_destroy(); // Distrugem datele sesiunii

// Redirect login
header("Location: login.php");
exit;
