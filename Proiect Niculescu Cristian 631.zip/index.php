<?php
session_start(); 


require_once 'db.php';

// Get sorting parameters
$sort_by = isset($_GET['sort_by']) ? $_GET['sort_by'] : 'title';
$sort_order = isset($_GET['sort_order']) ? $_GET['sort_order'] : 'asc';

// Get pagination parameters
$items_per_page = isset($_GET['items_per_page']) ? (int)$_GET['items_per_page'] : 10;
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$offset = ($page - 1) * $items_per_page;

// Fetch books with sorting and pagination
$books = get_all_books($sort_by, $sort_order, $items_per_page, $offset);
$total_books = get_books_count();
$total_pages = ceil($total_books / $items_per_page);


$sql = "SELECT category_name FROM Categories";
$result = $conn->query($sql);

$categories = [];
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $categories[] = $row['category_name'];
    }
}

// Setam variabile
$storeName = "Cristian Books";
$currentTime = date('H');
$featuredCategory = $categories[array_rand($categories)];

// greeting
if ($currentTime < 12) {
    $greeting = "Good morning";
} elseif ($currentTime < 18) {
    $greeting = "Good afternoon";
} else {
    $greeting = "Good evening";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="style.css">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome to <?= $storeName; ?></title>
    <?php include 'header.php'; ?>

</head>
<body>
    
<div class="greeting-container">
    <h1><?= $greeting . ", welcome to " . $storeName; ?>!</h1>
    <h2>Category of the Day: 
        <a href="category.php?category=<?= urlencode($featuredCategory); ?>">
            <?= htmlspecialchars($featuredCategory); ?>
        </a>
    </h2>
</div>
    <div class="container">
    
        <h2>Select a Category</h2>
        <form action="category.php" method="get" class="category-form">
            <label for="category">Choose a category:</label>
            <select name="category" id="category">
                <option value="">Show All</option>
                <?php foreach ($categories as $category): ?>
                    <option value="<?= htmlspecialchars($category); ?>"><?= htmlspecialchars($category); ?></option>
                <?php endforeach; ?>
            </select>

            <label for="title">Search by title:</label>
            <input type="text" name="title" id="title" placeholder="Enter book title">

            <button type="submit">Filter Books</button>
        </form>

        <h2>Our Featured Books</h2>
        <div class="sort-options">
            <form action="index.php" method="get" class="sort-form">
                <label for="sort_by">Sort by:</label>
                <select name="sort_by" id="sort_by">
                    <option value="title" <?= $sort_by == 'title' ? 'selected' : ''; ?>>Title</option>
                    <option value="description" <?= $sort_by == 'description' ? 'selected' : ''; ?>>Description</option>
                    <option value="price" <?= $sort_by == 'price' ? 'selected' : ''; ?>>Price</option>
                </select>

                <label for="sort_order">Order:</label>
                <select name="sort_order" id="sort_order">
                    <option value="asc" <?= $sort_order == 'asc' ? 'selected' : ''; ?>>Ascending</option>
                    <option value="desc" <?= $sort_order == 'desc' ? 'selected' : ''; ?>>Descending</option>
                </select>

                <label for="items_per_page">Items per page:</label>
                <select name="items_per_page" id="items_per_page">
                    <option value="2" <?= $items_per_page == 2 ? 'selected' : ''; ?>>2</option>
                    <option value="4" <?= $items_per_page == 4 ? 'selected' : ''; ?>>4</option>
                    <option value="5" <?= $items_per_page == 5 ? 'selected' : ''; ?>>5</option>
                    <option value="10" <?= $items_per_page == 10 ? 'selected' : ''; ?>>10</option>
                    <option value="20" <?= $items_per_page == 20 ? 'selected' : ''; ?>>20</option>
                    <option value="50" <?= $items_per_page == 50 ? 'selected' : ''; ?>>50</option>
                </select>
                <button type="submit">Apply</button>
            </form>
        </div>

        <div class="book-list">
            <?php foreach ($books as $book): ?>
                <?php $isDiscounted = isset($book['discount_price']); ?>
                <div class="<?= $isDiscounted ? 'book discounted' : 'book'; ?>">
                    <h3><?= htmlspecialchars($book['title']); ?></h3>
                    <img src="<?= htmlspecialchars($book['cover']); ?>" alt="<?= htmlspecialchars($book['title']); ?> Cover" />
                    <p><strong>Description:</strong> <?= htmlspecialchars($book['description']); ?></p>
                    <p><strong>Category:</strong> 
                        <a href="category.php?category=<?= urlencode($book['category']); ?>">
                            <?= htmlspecialchars($book['category']); ?>
                        </a>
                    </p>
                    <p><strong>Price:</strong> 
                        <?php if ($isDiscounted): ?>
                            <span style="text-decoration: line-through;">$<?= number_format($book['price'], 2); ?></span>
                            <strong>Discounted Price:</strong> $<?= number_format($book['discount_price'], 2); ?>
                        <?php else: ?>
                            $<?= number_format($book['price'], 2); ?>
                        <?php endif; ?>
                    </p>

                    <?php if (isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true): ?>
                        <p><a href="edit_book.php?id=<?= htmlspecialchars($book['book_id']); ?>">Edit</a></p>
                    <?php endif; ?>
                </div>
            <?php endforeach; ?>
        </div>

        <div class="pagination">
            <?php if ($page > 1): ?>
                <a href="?page=1&items_per_page=<?= $items_per_page; ?>&sort_by=<?= $sort_by; ?>&sort_order=<?= $sort_order; ?>">First</a>
                <a href="?page=<?= $page - 1; ?>&items_per_page=<?= $items_per_page; ?>&sort_by=<?= $sort_by; ?>&sort_order=<?= $sort_order; ?>">Prev</a>
            <?php endif; ?>

            <?php if ($page > 2): ?>
                <span>...</span>
            <?php endif; ?>

            <?php if ($page > 1): ?>
                <a href="?page=<?= $page - 1; ?>&items_per_page=<?= $items_per_page; ?>&sort_by=<?= $sort_by; ?>&sort_order=<?= $sort_order; ?>"><?= $page - 1; ?></a>
            <?php endif; ?>

            <span><?= $page; ?></span>

            <?php if ($page < $total_pages): ?>
                <a href="?page=<?= $page + 1; ?>&items_per_page=<?= $items_per_page; ?>&sort_by=<?= $sort_by; ?>&sort_order=<?= $sort_order; ?>"><?= $page + 1; ?></a>
            <?php endif; ?>

            <?php if ($page < $total_pages - 1): ?>
                <span>...</span>
            <?php endif; ?>

            <?php if ($page < $total_pages): ?>
                <a href="?page=<?= $page + 1; ?>&items_per_page=<?= $items_per_page; ?>&sort_by=<?= $sort_by; ?>&sort_order=<?= $sort_order; ?>">Next</a>
                <a href="?page=<?= $total_pages; ?>&items_per_page=<?= $items_per_page; ?>&sort_by=<?= $sort_by; ?>&sort_order=<?= $sort_order; ?>">Last</a>
            <?php endif; ?>
        </div>
    </div>

    <footer>
        <p>&copy; <?= date('Y'); ?> Cristian Books. All rights reserved.</p>
    </footer>
</body>
</html>

