<?php
session_start();
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    header("Location: login.php");
    exit;
}

// includem functiile bazei de date
require 'db.php';

// Luam book id
$idToEdit = $_GET['id'] ?? '';
$bookToEdit = get_book_by_id($idToEdit); // Use the function to fetch book details by ID

// Redirectionare daca nu s-a gasit cartea
if (!$bookToEdit) {
    header("Location: index.php");
    exit;
}

// Initializare mesaj eroare
$errors = [];

// formulare submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // campuri formular
    $title = trim($_POST['title']);
    $description = trim($_POST['description']);
    $category = trim($_POST['category']);
    $price = (float)$_POST['price'];

    if (empty($title) || empty($description) || empty($category) || $price <= 0) {
        $errors[] = "All fields are required, and the price must be a positive number.";
    }

    // Validam titlul si descriere
    if (strlen($title) > 100) {
        $errors[] = "The title must not exceed 100 characters.";
    }
    if (strlen($description) > 500) {
        $errors[] = "The description must not exceed 500 characters.";
    }

    // Validam upload
    if (!empty($_FILES['cover']['tmp_name'])) {
        $allowedTypes = ['image/jpeg', 'image/png', 'image/gif'];
        $maxFileSize = 2 * 1024 * 1024; // 2 MB

        if (!in_array($_FILES['cover']['type'], $allowedTypes)) {
            $errors[] = "Only JPEG, PNG, and GIF files are allowed.";
        }
        if ($_FILES['cover']['size'] > $maxFileSize) {
            $errors[] = "The file size must not exceed 2 MB.";
        }
    }

    // Verificam de erori pentru a continua
    if (empty($errors)) {
        $updatedData = [
            'title' => $title,
            'description' => $description,
            'category' => $category,
            'price' => $price,
            'cover' => $bookToEdit['cover'] 
        ];

        // gestionarea incarcarii fisierelor
        if (!empty($_FILES['cover']['tmp_name'])) {
            $coverPath = 'covers/' . basename($_FILES['cover']['name']);
            if (move_uploaded_file($_FILES['cover']['tmp_name'], $coverPath)) {
                $updatedData['cover'] = $coverPath;
            }
        }

        // Updatam cartea in baza de date
        $updateSuccess = update_book($idToEdit, $updatedData);

        if ($updateSuccess) {
            header("Location: index.php");
            exit;
        } else {
            $errors[] = "Error updating the book.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Book - <?= htmlspecialchars($bookToEdit['title']); ?></title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <?php include 'header.php'; ?>

    <div class="edit-book-container">
        <h1>Edit Book - <?= htmlspecialchars($bookToEdit['title']); ?></h1>

        <!-- Display errors if there are any -->
        <?php if (!empty($errors)): ?>
            <div class="error-message">
                <ul>
                    <?php foreach ($errors as $error): ?>
                        <li><?= htmlspecialchars($error); ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>

        <form method="post" enctype="multipart/form-data" class="edit-book-form">
            <div class="form-group">
                <label for="title">Title:</label>
                <input type="text" name="title" id="title" value="<?= htmlspecialchars($bookToEdit['title']); ?>" required>
            </div>

            <div class="form-group">
                <label for="description">Description:</label>
                <textarea name="description" id="description" required><?= htmlspecialchars($bookToEdit['description']); ?></textarea>
            </div>

            <div class="form-group">
                <label for="category">Category:</label>
                <input type="text" name="category" id="category" value="<?= htmlspecialchars($bookToEdit['category']); ?>" required>
            </div>

            <div class="form-group">
                <label for="price">Price:</label>
                <input type="number" name="price" id="price" step="0.01" min="0" value="<?= htmlspecialchars($bookToEdit['price']); ?>" required>
            </div>

            <div class="form-group">
                <label for="cover">Cover Image:</label>
                <br>
                <img src="<?= htmlspecialchars($bookToEdit['cover']); ?>" alt="Current Cover" class="current-cover">
                <br>
                <input type="file" name="cover" id="cover">
            </div>

            <button type="submit" class="save-button">Save Changes</button>
        </form>
    </div>
</body>
</html>
