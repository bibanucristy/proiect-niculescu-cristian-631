<?php
require 'auth.php'; // Include authorization logic

$jsonData = file_get_contents('books.json');
$books = json_decode($jsonData, true);

// Get the book ID from the query string
$idToEdit = $_GET['id'] ?? '';
$bookToEdit = null;

// Find the book to edit by ID
foreach ($books as &$book) {
    if ($book['id'] == $idToEdit) {
        $bookToEdit = &$book;
        break;
    }
}

// Redirect if the book was not found
if ($bookToEdit === null) {
    header("Location: index.php");
    exit;
}

// Initialize error messages
$errors = [];

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Required fields
    $title = trim($_POST['title']);
    $description = trim($_POST['description']);
    $category = trim($_POST['category']);
    $price = (float)$_POST['price'];

    if (empty($title) || empty($description) || empty($category) || $price <= 0) {
        $errors[] = "All fields are required, and the price must be a positive number.";
    }

    // Validate title and description length
    if (strlen($title) > 100) {
        $errors[] = "The title must not exceed 100 characters.";
    }
    if (strlen($description) > 500) {
        $errors[] = "The description must not exceed 500 characters.";
    }

    // Validate file upload
    if (!empty($_FILES['cover']['tmp_name'])) {
        $allowedTypes = ['image/jpeg', 'image/png', 'image/gif'];
        $maxFileSize = 2 * 1024 * 1024; // 2 MB

        if (!in_array($_FILES['cover']['type'], $allowedTypes)) {
            $errors[] = "Only JPEG, PNG, and GIF files are allowed.";
        }
        if ($_FILES['cover']['size'] > $maxFileSize) {
            $errors[] = "The file size must not exceed 2 MB.";
        }
    }

    // If no errors, proceed with updating the book data
    if (empty($errors)) {
        $bookToEdit['title'] = $title;
        $bookToEdit['description'] = $description;
        $bookToEdit['category'] = $category;
        $bookToEdit['price'] = $price;

        // Handle file upload
        if (!empty($_FILES['cover']['tmp_name'])) {
            $coverPath = 'covers/' . basename($_FILES['cover']['name']);
            move_uploaded_file($_FILES['cover']['tmp_name'], $coverPath);
            $bookToEdit['cover'] = $coverPath;
        }

        // Save the updated book data
        file_put_contents('books.json', json_encode($books, JSON_PRETTY_PRINT));
        header("Location: index.php");
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Book - <?= htmlspecialchars($bookToEdit['title']); ?></title>
</head>
<body>
    <h1>Edit Book - <?= htmlspecialchars($bookToEdit['title']); ?></h1>

    <!-- Display errors if there are any -->
    <?php if (!empty($errors)): ?>
        <div style="color: red;">
            <ul>
                <?php foreach ($errors as $error): ?>
                    <li><?= htmlspecialchars($error); ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>

    <form method="post" enctype="multipart/form-data">
        <label for="title">Title:</label>
        <input type="text" name="title" id="title" value="<?= htmlspecialchars($bookToEdit['title']); ?>" required>
        <br>

        <label for="description">Description:</label>
        <textarea name="description" id="description" required><?= htmlspecialchars($bookToEdit['description']); ?></textarea>
        <br>

        <label for="category">Category:</label>
        <select name="category" id="category" required>
            <?php
            $categories = [
                "Fiction", 
                "Science Fiction", 
                "Historical Fiction", 
                "Non-Fiction", 
                "Fantasy", 
                "Science", 
                "Children's Books", 
                "Post-Apocalyptic"
            ];
            foreach ($categories as $categoryOption): ?>
                <option value="<?= htmlspecialchars($categoryOption); ?>" <?= $bookToEdit['category'] === $categoryOption ? 'selected' : ''; ?>>
                    <?= htmlspecialchars($categoryOption); ?>
                </option>
            <?php endforeach; ?>
        </select>
        <br>

        <label for="price">Price:</label>
        <input type="number" name="price" id="price" step="0.01" min="0" value="<?= htmlspecialchars($bookToEdit['price']); ?>" required>
        <br>

        <label for="cover">Cover Image:</label>
        <br>
        <img src="<?= htmlspecialchars($bookToEdit['cover']); ?>" alt="Current Cover" style="max-width: 150px; max-height: 200px;">
        <br>
        <input type="file" name="cover" id="cover">
        <br>

        <button type="submit">Save Changes</button>
    </form>
</body>
</html>
