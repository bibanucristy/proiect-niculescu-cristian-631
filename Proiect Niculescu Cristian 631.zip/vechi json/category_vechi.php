<?php
// Load the book data from the JSON file
$jsonData = file_get_contents('books.json');
$books = json_decode($jsonData); // Decode as object

// Check if decoding was successful
if (json_last_error() !== JSON_ERROR_NONE) {
    echo "<p>Error: Invalid JSON data. Please check the books.json file.</p>";
    $books = [];
}

// Define valid categories
$categories = [
    "Fiction", 
    "Science Fiction", 
    "Historical Fiction", 
    "Non-Fiction", 
    "Fantasy", 
    "Science", 
    "Children's Books", 
    "Post-Apocalyptic"
];

// Get the category and title from the query string
$selectedCategory = isset($_GET['category']) ? $_GET['category'] : '';
$searchTitle = isset($_GET['title']) ? trim($_GET['title']) : '';

// Validate the selected category
if ($selectedCategory === '' || $selectedCategory === 'Show All') {
    $filteredBooks = $books;
} elseif (in_array($selectedCategory, $categories)) {
    // Filter books by category if the category is valid
    $filteredBooks = array_filter($books, function ($book) use ($selectedCategory) {
        return strtolower($book->category) === strtolower($selectedCategory);
    });
} else {
    $filteredBooks = [];
}

// Further filter books by title if a title is provided
if ($searchTitle !== '') {
    $filteredBooks = array_filter($filteredBooks, function ($book) use ($searchTitle) {
        return stripos($book->title, $searchTitle) !== false; // Case-insensitive title search
    });
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Books in <?= htmlspecialchars($selectedCategory); ?> Category</title>
    <style>
        .book-list {
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
        }
        .book {
            border: 1px solid #ddd;
            padding: 10px;
            width: 200px;
        }
        .book img {
            width: 100%;
            height: auto;
        }
    </style>
</head>
<body>
    <h1>
        <?= $selectedCategory === '' || $selectedCategory === 'Show All' 
            ? 'All Books' 
            : 'Books in ' . htmlspecialchars($selectedCategory) . ' Category'; ?>
    </h1>

    <?php if ($searchTitle !== ''): ?>
        <h2>Search Results for "<?= htmlspecialchars($searchTitle); ?>"</h2>
    <?php endif; ?>

    <div class="book-list">
        <?php if (count($filteredBooks) > 0): ?>
            <?php foreach ($filteredBooks as $book): ?>
                <div class='book'>
                    <h3><?= $book->title; ?></h3>
                    <img src="<?= $book->cover; ?>" alt="<?= $book->title; ?> Cover" />
                    <p><strong>Description:</strong> <?= $book->description; ?></p>
                    <?php if (isset($book->discount_price)): ?>
                        <p><strong>Price:</strong> <span style="text-decoration: line-through;">$<?= number_format($book->price, 2); ?></span>
                        <strong>Discounted Price:</strong> $<?= number_format($book->discount_price, 2); ?></p>
                    <?php else: ?>
                        <p><strong>Price:</strong> $<?= number_format($book->price, 2); ?></p>
                    <?php endif; ?>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <p>No books found.</p>
        <?php endif; ?>
    </div>
</body>
</html>
