<?php
session_start(); 


require_once 'db.php';


$books = get_all_books();


$sql = "SELECT category_name FROM Categories";
$result = $conn->query($sql);

$categories = [];
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $categories[] = $row['category_name'];
    }
}

// Setam variabile
$storeName = "Cristian Books";
$currentTime = date('H');
$featuredCategory = $categories[array_rand($categories)];

// greeting
if ($currentTime < 12) {
    $greeting = "Good morning";
} elseif ($currentTime < 18) {
    $greeting = "Good afternoon";
} else {
    $greeting = "Good evening";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="style.css">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome to <?= $storeName; ?></title>
    <?php include 'header.php'; ?>

</head>
<body>
    
<div class="greeting-container">
    <h1><?= $greeting . ", welcome to " . $storeName; ?>!</h1>
    <h2>Category of the Day: 
        <a href="category.php?category=<?= urlencode($featuredCategory); ?>">
            <?= htmlspecialchars($featuredCategory); ?>
        </a>
    </h2>
</div>
    <div class="container">
    
        <h2>Select a Category</h2>
        <form action="category.php" method="get" class="category-form">
            <label for="category">Choose a category:</label>
            <select name="category" id="category">
                <option value="">Show All</option>
                <?php foreach ($categories as $category): ?>
                    <option value="<?= htmlspecialchars($category); ?>"><?= htmlspecialchars($category); ?></option>
                <?php endforeach; ?>
            </select>

            <label for="title">Search by title:</label>
            <input type="text" name="title" id="title" placeholder="Enter book title">

            <button type="submit">Filter Books</button>
        </form>

        <h2>Our Featured Books</h2>
        <div class="book-list">
            <?php foreach ($books as $book): ?>
                <?php $isDiscounted = isset($book['discount_price']); ?>
                <div class="<?= $isDiscounted ? 'book discounted' : 'book'; ?>">
                    <h3><?= htmlspecialchars($book['title']); ?></h3>
                    <img src="<?= htmlspecialchars($book['cover']); ?>" alt="<?= htmlspecialchars($book['title']); ?> Cover" />
                    <p><strong>Description:</strong> <?= htmlspecialchars($book['description']); ?></p>
                    <p><strong>Category:</strong> 
                        <a href="category.php?category=<?= urlencode($book['category']); ?>">
                            <?= htmlspecialchars($book['category']); ?>
                        </a>
                    </p>
                    <p><strong>Price:</strong> 
                        <?php if ($isDiscounted): ?>
                            <span style="text-decoration: line-through;">$<?= number_format($book['price'], 2); ?></span>
                            <strong>Discounted Price:</strong> $<?= number_format($book['discount_price'], 2); ?>
                        <?php else: ?>
                            $<?= number_format($book['price'], 2); ?>
                        <?php endif; ?>
                    </p>

                    <?php if (isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true): ?>
                        <p><a href="edit_book.php?id=<?= htmlspecialchars($book['book_id']); ?>">Edit</a></p>
                    <?php endif; ?>
                </div>
            <?php endforeach; ?>
        </div>
    </div>

    <footer>
        <p>&copy; <?= date('Y'); ?> Cristian Books. All rights reserved.</p>
    </footer>
</body>
</html>

