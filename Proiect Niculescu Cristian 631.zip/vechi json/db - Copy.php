<?php
// Parametri login db
$host = 'localhost';
$username = 'root';
$password = ''; 
$dbname = 'bookstore';

// Facem conexiunea
$conn = mysqli_connect($host, $username, $password, $dbname);

// Verificam conexiunea
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Functie sa luam toate cartile
function get_all_books() {
    global $conn;
    $sql = "SELECT b.book_id, b.title, b.description, b.cover, b.price, b.discount_price, 
                   GROUP_CONCAT(DISTINCT c.category_name SEPARATOR ', ') AS category
            FROM Books b
            LEFT JOIN Book_Categories bc ON b.book_id = bc.book_id
            LEFT JOIN Categories c ON bc.category_id = c.category_id
            GROUP BY b.book_id";

    $result = mysqli_query($conn, $sql);

    $books = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $book = [
            "book_id" => $row['book_id'],
            "title" => $row['title'],
            "description" => $row['description'],  // Include description
            "cover" => $row['cover'],
            "price" => (float)$row['price'],
            "discount_price" => isset($row['discount_price']) ? (float)$row['discount_price'] : null,
            "category" => $row['category']
        ];
        $books[] = $book;
    }
    return $books;
}


// Functie sa luam cartile dupa categorie
function get_books_by_category($category) {
    global $conn;
    $sql = "SELECT b.book_id, b.title, b.description, b.cover, b.price, b.discount_price, 
                   GROUP_CONCAT(DISTINCT c.category_name SEPARATOR ', ') AS category
            FROM Books b
            LEFT JOIN Book_Categories bc ON b.book_id = bc.book_id
            LEFT JOIN Categories c ON bc.category_id = c.category_id
            WHERE c.category_name = ?
            GROUP BY b.book_id";

    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "s", $category);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    $books = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $book = [
            "book_id" => $row['book_id'],
            "title" => $row['title'],
            "description" => $row['description'],
            "cover" => $row['cover'],
            "price" => (float)$row['price'],
            "discount_price" => isset($row['discount_price']) ? (float)$row['discount_price'] : null,
            "category" => $row['category']
        ];
        $books[] = $book;
    }

    mysqli_stmt_close($stmt);
    return $books;
}


// Functie sa luam carti dupa titlu
function get_book_by_title($title) {
    global $conn;
    $sql = "SELECT b.title, b.price, b.book_id, 
                   GROUP_CONCAT(c.category_name SEPARATOR ', ') AS categories
            FROM Books b
            JOIN Book_Categories bc ON b.book_id = bc.book_id
            JOIN Categories c ON bc.category_id = c.category_id
            WHERE b.title = ?
            GROUP BY b.book_id";

    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "s", $title);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    $book = mysqli_fetch_assoc($result);
    if ($book) {
        $book['price'] = (float)$book['price'];
    }

    mysqli_stmt_close($stmt);
    return $book;
}

// Functie sa luam carti dupa id

function get_book_by_id($id) {
    global $conn;
    $sql = "SELECT b.book_id, b.title, b.description, b.price, b.cover, 
                   GROUP_CONCAT(c.category_name SEPARATOR ', ') AS category
            FROM Books b
            LEFT JOIN Book_Categories bc ON b.book_id = bc.book_id
            LEFT JOIN Categories c ON bc.category_id = c.category_id
            WHERE b.book_id = ?
            GROUP BY b.book_id";

    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "i", $id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $book = mysqli_fetch_assoc($result);
    mysqli_stmt_close($stmt);

    return $book;
}


// Functiile sa updatam detaliile dupa titlu
function update_book($id, $newData) {
    global $conn;

    // Pregatim statement update
    $sql = "UPDATE Books 
            SET title = ?, description = ?, price = ?, cover = ? 
            WHERE book_id = ?";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param(
        $stmt,
        "ssdsi",
        $newData['title'],
        $newData['description'],
        $newData['price'],
        $newData['cover'],
        $id
    );

    $success = mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);

    return $success;
}

?>
