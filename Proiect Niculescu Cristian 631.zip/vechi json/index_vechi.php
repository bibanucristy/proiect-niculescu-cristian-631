<?php
session_start(); // Start the session to check login status

// Load the book data from the JSON file
$jsonData = file_get_contents('books.json');

if ($jsonData === false) {
    echo "<p>Error: Could not load book data.</p>";
    $books = []; // Set an empty array to prevent further errors
} else {
    // Decode the JSON data into a PHP object
    $books = json_decode($jsonData);

    // Check if decoding was successful
    if (json_last_error() !== JSON_ERROR_NONE) {
        echo "<p>Error: Invalid JSON data. Please check the books.json file.</p>";
        $books = []; // Set an empty array to prevent further errors
    }
}

// Set other variables
$storeName = "John's Book Emporium";
$categories = [
  "Fiction", 
  "Science Fiction", 
  "Historical Fiction", 
  "Non-Fiction", 
  "Fantasy", 
  "Science", 
  "Children's Books", 
  "Post-Apocalyptic"
];
$currentTime = date('H');
$featuredCategory = $categories[array_rand($categories)];

// Determine greeting based on time of day
if ($currentTime < 12) {
    $greeting = "Good morning";
} elseif ($currentTime < 18) {
    $greeting = "Good afternoon";
} else {
    $greeting = "Good evening";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<style>
   .logout-button {
        display: inline-block;
        padding: 8px 15px;
        background-color: #ff4d4d;
        color: white;
        text-decoration: none;
        border-radius: 5px;
        font-size: 14px;
    }

    .logout-button:hover {
        background-color: #e60000;
    }
  .book-list {
    display: flex;
    flex-wrap: wrap;
    gap: 20px;
  }
  .book {
    border: 1px solid #ddd;
    padding: 10px;
    width: 200px;
  }
  .book img {
    width: 100%;
    height: auto;
  }
  /* Highlight discounted books with a green border */
  .discounted {
    border: 2px solid green;
  }
</style>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome to <?= $storeName; ?></title>
</head>
<body>
<?php if (isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true): ?>
    <p><a href="logout.php" class="logout-button">Logout</a></p>
<?php endif; ?>

    <h1><?= $greeting . ", welcome to " . $storeName; ?>!</h1>
    <h2>Category of the Day: <?= $featuredCategory; ?></h2>

    <h2>Select a Category</h2>
    <form action="category.php" method="get" class="category-form">
        <label for="category">Choose a category:</label>
        <select name="category" id="category">
            <option value="">Show All</option>
            <?php foreach ($categories as $category): ?>
                <option value="<?= htmlspecialchars($category); ?>"><?= htmlspecialchars($category); ?></option>
            <?php endforeach; ?>
        </select>

        <label for="title">Search by title:</label>
        <input type="text" name="title" id="title" placeholder="Enter book title">

        <button type="submit">Filter Books</button>
    </form>

    <h2>Our Featured Books</h2>
    <div class="book-list">
        <?php foreach ($books as $book): ?>
            <?php $isDiscounted = isset($book->discount_price); ?>
            <div class="<?= $isDiscounted ? 'book discounted' : 'book'; ?>">
                <h3><?= $book->title; ?></h3>
                <img src="<?= $book->cover; ?>" alt="<?= $book->title; ?> Cover" />
                <p><strong>Description:</strong> <?= $book->description; ?></p>
                <p><strong>Category:</strong> 
                   <a href="category.php?category=<?= urlencode($book->category); ?>">
                       <?= $book->category; ?>
                   </a>
                </p>
                <p><strong>Price:</strong> 
                    <?php if ($isDiscounted): ?>
                        <span style="text-decoration: line-through;">$<?= number_format($book->price, 2); ?></span>
                        <strong>Discounted Price:</strong> $<?= number_format($book->discount_price, 2); ?>
                    <?php else: ?>
                        $<?= number_format($book->price, 2); ?>
                    <?php endif; ?>
                </p>

                <!-- Show edit link if logged in -->
                <?php if (isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true): ?>
                  <p><a href="edit_book.php?id=<?= $book->id; ?>">Edit</a></p>
                  <?php endif; ?>
            </div>
        <?php endforeach; ?>
    </div>

    <p>Here are some of our book categories:</p>
    <ul>
        <?php foreach ($categories as $category): ?>
            <li><a href="category.php?category=<?= urlencode($category); ?>"><?= $category; ?></a></li>
        <?php endforeach; ?>
    </ul>

    <footer>
        <p>&copy; <?= date('Y'); ?> John's Book Emporium. All rights reserved.</p>
    </footer>

</body>
</html>
