<?php

require_once 'db.php';

// Preia toate categ din meniu drop down
$sql = "SELECT category_name FROM Categories";
$result = $conn->query($sql);

$categories = [];
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $categories[] = $row['category_name'];
    }
}
?>

<header>
    <nav class="navbar">
        
        <a href="index.php" class="logo">
            <img src="logoo.png" alt="Bookstore Logo">
        </a>

        <!-- Categorii cu dropdown -->
        <div class="nav-center">
            <div class="dropdown">
                <button class="dropdown-button">Categories</button>
                <div class="dropdown-content">
                    <?php foreach ($categories as $category): ?>
                        <a href="category.php?category=<?= urlencode($category); ?>">
                            <?= htmlspecialchars($category); ?>
                        </a>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>

        <!-- buton logout -->
        <div class="nav-right">
            <?php if (isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true): ?>
                <a href="logout.php" class="logout-button">Logout</a>
            <?php endif; ?>
        </div>
    </nav>
</header>
