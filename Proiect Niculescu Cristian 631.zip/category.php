<?php
session_start(); // Start sesiune daca e nevoie

// Includem functiile baze ide date
require 'db.php';

// Luam titlul si categoria
$selectedCategory = $_GET['category'] ?? '';
$searchTitle = $_GET['title'] ?? '';

// Preluam carti in functie de titlu si categorie
if ($selectedCategory === '' || $selectedCategory === 'Show All') {
    $filteredBooks = get_all_books(); // Fetch all books if no category is selected
} else {
    $filteredBooks = get_books_by_category($selectedCategory);
}

// Filtram mai departe cartile dupa titlu daca se da
if (!empty($searchTitle)) {
    $filteredBooks = array_filter($filteredBooks, function ($book) use ($searchTitle) {
        return stripos($book['title'], $searchTitle) !== false; // Case-insensitive search
    });
}

// Luam toate categoriile pt dropdown
$sql = "SELECT category_name FROM Categories";
$result = $conn->query($sql);

$categories = [];
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $categories[] = $row['category_name'];
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Books in <?= htmlspecialchars($selectedCategory); ?> Category</title>
    <link rel="stylesheet" href="style.css">
    <?php include 'header.php'; ?>
</head>
<body>    

    <h1>
        <?= empty($selectedCategory) || $selectedCategory === 'Show All' 
            ? 'All Books' 
            : 'Books in ' . htmlspecialchars($selectedCategory) . ' Category'; ?>
    </h1>

    <?php if (!empty($searchTitle)): ?>
        <h2>Search Results for "<?= htmlspecialchars($searchTitle); ?>"</h2>
    <?php endif; ?>

    <div class="book-list">
        <?php if (count($filteredBooks) > 0): ?>
            <?php foreach ($filteredBooks as $book): ?>
                <div class='book'>
                    <h3><?= htmlspecialchars($book['title']); ?></h3>
                    <img src="<?= htmlspecialchars($book['cover']); ?>" alt="<?= htmlspecialchars($book['title']); ?> Cover" />
                    <p><strong>Description:</strong> <?= htmlspecialchars($book['description']); ?></p>
                    <p><strong>Category:</strong> <?= htmlspecialchars($book['category']); ?></p>
                    <p><strong>Price:</strong> 
                        <?php if (isset($book['discount_price'])): ?>
                            <span style="text-decoration: line-through;">$<?= number_format($book['price'], 2); ?></span>
                            <strong>Discounted Price:</strong> $<?= number_format($book['discount_price'], 2); ?>
                        <?php else: ?>
                            $<?= number_format($book['price'], 2); ?>
                        <?php endif; ?>
                    </p>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <p>No books found.</p>
        <?php endif; ?>
    </div>
    <footer>
        <p>&copy; <?= date('Y'); ?> Cristian Books. All rights reserved.</p>
    </footer>
</body>
</html>
